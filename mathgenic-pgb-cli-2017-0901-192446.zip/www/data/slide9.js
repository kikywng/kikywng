(function(){var loadHandler=window['sl_{0CD57BF2-0285-4CA7-A2DF-5F25449D6959}'];loadHandler&&loadHandler(8, '<div id="spr0_53d29e4"><div id="spr1_53d29e4" class="kern"><img id="img9_53d29e4" src="data/img6.png" width="960px" height="540px" alt="" style="left:0px;top:0px;"/><img id="img0_53d29e4" src="data/img7.png" width="960" height="138" alt="" style="top:402px;"/><img id="img1_53d29e4" src="data/img8.png" width="960" height="402" alt=""/><img id="img2_53d29e4" src="data/img2.png" width="960" height="180" alt="" style="top:296.717px;"/><img id="img3_53d29e4" src="data/img9.png" width="1583.505" height="402" alt="" style="left:-311.753px;top:126px;"/></div><div id="spr2_53d29e4" class="kern"><div id="spr3_53d29e4" style="left:117px;top:-1px;"><img id="img4_53d29e4" src="data/img44.png" width="727" height="98" alt="Konsep Dasar Aljabar"/></div><div id="spr4_53d29e4" style="left:118px;top:471px;"><img id="img5_53d29e4" src="data/img27.png" width="724" height="86" alt=""/></div><div id="spr5_53d29e4" style="left:193px;top:110px;"><img id="img6_53d29e4" src="data/img45.png" width="552" height="344" alt="1. Teori Binomal\
	Rumus :\
	( a + n )n = an + nn-1b +  𝑛(𝑛−1) 2  an-2b + 	 𝑛(𝑛−1)(𝑛−2) 6        an-3b + … + bn\
2. Menyederhanakan Bentuk Akar\
	Rumus :\
	a.  𝑛 𝑎𝑏  =  𝑛 𝑎  x  𝑛 𝑏 \
	b. ( a  𝑏  )2  = a2 b\
3. Operasi Pada Bentuk Akar\
	Rumus :\
	a. x  𝑛 𝑎  + y  𝑛 𝑎  = ( x + y )  𝑛 𝑎 \
	b. x  𝑛 𝑎  + y  𝑛 𝑎  + b +  𝑛 𝑐  = ( x + y )  𝑛 𝑎  + b +  𝑛 𝑐 \
c. x  𝑛 𝑎  - y  𝑛 𝑎  = ( x – y )  𝑛 𝑎 \
	d. x  𝑛 𝑎  - y  𝑛 𝑎  + b +  𝑛 𝑐  = ( x – y )  𝑛 𝑎  + b +  𝑛 𝑐 \
\
\
\
"/></div><div id="spr6_53d29e4" style="left:144px;top:478.544px;"><a id="hl0_53d29e4" href="#" onclick="document.getElementById(\'coreSpr_3960357\').getCore().processTriggerEffect(this);document.getElementById(\'coreSpr_3960357\').getCore().gotoSlide(7);return false;"><img id="img7_53d29e4" src="data/img46.png" width="61" height="61" alt="" style="left:0.228px;top:0.228px;"/></a></div><div id="spr7_53d29e4" style="left:750px;top:473.272px;"><a id="hl1_53d29e4" href="#" onclick="document.getElementById(\'coreSpr_3960357\').getCore().processTriggerEffect(this);document.getElementById(\'coreSpr_3960357\').getCore().gotoSlide(1);return false;"><img id="img8_53d29e4" src="data/img37.png" width="61" height="61" alt="" style="left:0.228px;top:0.228px;"/></a></div></div></div>');})();